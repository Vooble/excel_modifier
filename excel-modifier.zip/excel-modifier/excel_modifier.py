from openpyxl import load_workbook
import os

def process_excel(path_in: str, path_out: str):
    wb = load_workbook(path_in)
    ws = wb.active

    # 1. elimina prime due righe
    ws.delete_rows(1, 2)

    # 2. elimina prima colonna
    ws.delete_cols(1, 1)

    # 3. inserisci colonna "Name" tra B e C
    ws.insert_cols(3, 1)
    ws.cell(row=1, column=3, value="Name")

    # 4. formule in colonna C
    max_row = ws.max_row
    for row in range(2, max_row + 1):
        formula = f'=CONCATENATE(A{row};" - ";B{row})'
        ws.cell(row=row, column=3, value=formula)

    wb.save(path_out)

if __name__ == "__main__":
    infile = "input.xlsx"
    outfile = "output.xlsx"
    if os.path.exists(infile):
        process_excel(infile, outfile)
        print(f"File salvato come {outfile}")
    else:
        print(f"Manca il file {infile} nella stessa cartella")
